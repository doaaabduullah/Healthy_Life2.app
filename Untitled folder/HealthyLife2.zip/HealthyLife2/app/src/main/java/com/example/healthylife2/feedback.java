package com.example.healthylife2;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Switch;
import android.widget.ToggleButton;


public class feedback extends Fragment {
    RadioGroup male , female;
   CheckBox checkBox;
   Switch switch1;
    ToggleButton toggleButton;
    Button btnsubmit;
    RatingBar myratingbar;
    Button btnrate;
    EditText date;
    DatePickerDialog datePickerDialog;
    EditText time;
    TimePickerDialog timePickerDialog;


    @NonNull
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @NonNull ViewGroup
            container, @NonNull Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.fragment_feedback,container,false);
        return view;

        }
}