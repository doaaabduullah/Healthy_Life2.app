package com.example.healthylife2;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;


public class mineActivity_nav extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine_nav);
        drawerLayout = findViewById(R.id.nev_main);
        Toolbar toolbar = findViewById(R.id.Toolbar);
        NavigationView navigationView = findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(this);
        getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new HomeFragment());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_draw_open, R.string.navigation_draw_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        if(savedInstanceState==null)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container, new HomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nev_main);

        }



    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId())
        {
            case R.id.anemia:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new anemia_fragment()).commit();
                break;
            case R.id.blood_pressure:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new blood_pressure_Fragment()).commit();
                break;
            case R.id.drinks:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new Fat_burning_drinks()).commit();
                break;
            case R.id.loss_weight:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new loss_weight()).commit();
                break;
            case R.id.Medication:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new Medication()).commit();
                break;
            case R.id.Osteoporosis:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new Osteoporosis_Fragment()).commit();
                break;
            case R.id.logout0:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new Logout()).commit();
                break;
            case R.id.contactus:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new contactus()).commit();
                break;
            case R.id.feedback:
                getSupportFragmentManager().beginTransaction().replace(R.id.Fragment_container,new feedback()).commit();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    public void onBacKPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START))
        {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }






    }
}